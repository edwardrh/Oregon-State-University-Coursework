How to Compile Program smallsh.c

$ gcc smallsh.c
$ a.out

