<?php
	define('DB_HOST', oniddb.cws.oregonstate.edu);
	define('DB_USER', edwardrh-db);
	define('DB_PASSWORD', ItMt19oEL8hOxWhN);
	define('DB_NAME', edwardrh-db);
?>